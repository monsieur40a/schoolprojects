public class ItemNotFoundException extends RuntimeException{
}
