public interface Armor extends Item
{
    int getSlot();
    int getRating();
}
