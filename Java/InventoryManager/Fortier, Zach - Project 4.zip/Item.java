public interface Item
{
    String getName();
    int getGoldValue();
    double getWeight();
    double getValueWeightRatio();
}
