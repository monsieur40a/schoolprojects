public interface Weapon extends Item
{
    int getDamage();
}
