public class EmptyListException
        extends RuntimeException
{
}